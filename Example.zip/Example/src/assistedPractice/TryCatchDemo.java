package assistedPractice;

public class TryCatchDemo {

	public static void main(String[] args) {
        try {
            // Code that might throw an exception
            int[] numbers = { 1, 2, 3 };
            System.out.println("Trying to access an element outside the array bounds...");
            int value = numbers[5]; // This will throw an ArrayIndexOutOfBoundsException
            System.out.println("This line will not be reached due to the exception.");
        } catch (ArrayIndexOutOfBoundsException e) {
            // Catch block to handle the specific exception
            System.out.println("Array index out of bounds!");
        } finally {
            // Finally block will execute regardless of whether an exception occurred
            System.out.println("Finally block executed.");
        }

        // Code continues execution after the try-catch block
        System.out.println("Program continues after handling the exception.");
    }
	
	
}
