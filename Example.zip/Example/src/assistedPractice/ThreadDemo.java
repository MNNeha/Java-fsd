package assistedPractice;

//Extending the Thread class
class MyThread extends ThreadDemo {
 public void run() {
     // Code to be executed by the thread when it starts
     System.out.println("Thread created by extending Thread class is running.");
 }

public void start() {
	// TODO Auto-generated method stub
	
}
}

//Implementing the Runnable interface
class MyRunnable implements Runnable {
 public void run() {
     // Code to be executed by the thread when it starts
     System.out.println("Thread created by implementing Runnable interface is running.");
 }
}


public class ThreadDemo {

	public static void main(String[] args) {
		// Creating and starting a thread by extending Thread class
        MyThread myThread = new MyThread();
        myThread.start();

        // Creating a thread by implementing Runnable interface
        MyRunnable myRunnable = new MyRunnable();
        Thread myRunnableThread = new Thread(myRunnable);
        myRunnableThread.start();

        // Main program continues after starting threads
        for (int i = 0; i < 3; i++) {
            System.out.println("Main program executing...");
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

	}

}
