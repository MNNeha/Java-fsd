package assistedPractice;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ExceptionHandlingExample {

	public static void main(String[] args) throws IOException {
	System.out.println("ExceptionHandlingExample: ");
	
	Scanner sc=new Scanner(System.in);
	System.out.println(" Enter the Land size?  ");
	int LandSize = sc.nextInt();
	
	System.out.println(" In to how pieces you want divide this land. please dont Enter 0.  ");
	int noofPeicestoDivide = sc.nextInt();
	
	if(noofPeicestoDivide ==0) {
		System.out.println("zero was entered .so won't calculate the Landsize. ");
		
		
		System.out.println("so here size of each land after division "+LandSize / noofPeicestoDivide);
	}
	
	// Initializing FileReader variable as null for later assignment to a file instance.

	FileReader f = null;
	String myFile = "C:\\Temp\\log.txt";
	try {
		f = new FileReader(myFile);
		f.read(); // perform read operations using methods provided by the FileReader class, like read().

	} catch (FileNotFoundException e) {
		System.out.printf("Given file %s not found in the system.  \n"
				+ " Make sure it is in the said location and then retry\\n", myFile);

	}
        catch (IOException e) {
		System.out.printf("Given file %s is not read\n"
				+ " Make sure it has read permission for your account and then retry\\n", myFile);

	}
	finally {
		// always gets executed
		try {
			f.close();
		} catch (IOException e) {

		}
	}
	
	System.out.println("Thank You");

	}

}
