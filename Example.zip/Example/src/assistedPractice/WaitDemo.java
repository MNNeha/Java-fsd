package assistedPractice;

public class WaitDemo {

	public static void main(String[] args) {
		        final Object lock = new Object(); // Object to synchronize on
		        
		        Thread thread = new Thread(() -> {
		            synchronized (lock) {
		                try {
		                    System.out.println("Thread is waiting...");
		                    lock.wait(); // Thread waits until notified
		                    System.out.println("Thread is awake!");
		                } catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		        });
		        
		        thread.start(); // Starts the thread
		        
		        // Simulating some work for a while
		        try {
		            Thread.sleep(3000); // Sleep for 3 seconds
		        } catch (InterruptedException e) {
		            e.printStackTrace();
		        }
		        
		        synchronized (lock) {
		            lock.notify(); // Notifies the waiting thread
		        }
		    }

}
