package assistedPractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileIODemo {
	static String myFile = "C:\\Users\\My PC\\eclipse-workspace\\Example\\src\\Demo\\log.txt";
	static String myFile2 = "C:\\Users\\My PC\\eclipse-workspace\\Example\\src\\Demo\\log1.txt";
	static String myFolder = "C:\\Users\\My PC\\eclipse-workspace\\Example\\src\\Demo";


	public static void fileCopyDemo() {
		
		Path filePath = Path.of(myFile);
		Path filePath2 = Path.of(myFile2);
		try {
			Files.copy(filePath, filePath2, StandardCopyOption.REPLACE_EXISTING);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void fileReadDemo2() {
		try {
			Path filePath = Path.of(myFile);
			List<String> lines = Files.readAllLines(filePath);	
			
			for(String s: lines)System.out.println(s);			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void fileReadDemo1() {
		try {
			FileReader fr = new FileReader(myFile);			
			
			int ch = fr.read();
			System.out.println(ch);
			ch = fr.read();
			System.out.println(ch);		
			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void fileUpdateDemo(String contentToAdd) {
	    try {
	        // Append content to an existing file
	        Files.write(Path.of(myFile), contentToAdd.getBytes(), StandardOpenOption.APPEND);
	        System.out.println("File updated successfully!");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	public static void fileDeleteDemo() {
	    try {
	        // Delete the file
	        Files.deleteIfExists(Path.of(myFile));
	        System.out.println("File deleted successfully!");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	public static void main(String[] args) {

		//fileClassDemo();
		//fileReadDemo();
		
		//fileReadDemo2();
		fileCopyDemo();
		
		 fileReadDemo2(); // Read and print the content of the file
		    
		    // Copy the file
		    System.out.println("Copying file...");
		    fileCopyDemo();
		    System.out.println("File copied successfully!");
		    
		    // Update the file
		    System.out.println("Updating file...");
		    fileUpdateDemo("This is new content to add to the file\n");
		    System.out.println("File updated successfully!");
		    
		    // Delete the file
		    System.out.println("Deleting file...");
		    fileDeleteDemo();
		    System.out.println("File deleted successfully!");
	}

	
	}
