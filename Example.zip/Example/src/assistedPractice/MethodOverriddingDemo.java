package assistedPractice;

//Class A with a method display
class A {
 public void display() {
     System.out.println("Display method from class A");
 }
}

//Class B with a method display
class B {
 public void display() {
     System.out.println("Display method from class B");
 }
}

//Class C inheriting from both A and B and overriding the display method
class C extends A {
 @Override
 public void display() {
     super.display(); // Call the display method from class A
     System.out.println("Display method from class C");
 }
}

public class MethodOverriddingDemo {

	public static void main(String[] args) {
		  C obj = new C();
	        obj.display();

	}

}
