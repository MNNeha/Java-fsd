package assistedPractice;
//the four pillars of object-oriented programming - encapsulation, inheritance, polymorphism, and abstraction

// Encapsulation and Abstraction - Class representing a Book
class StoryBook {
    private String title;
    private String author;
    private int pages;

    // Constructor to initialize Book object
    public StoryBook(String title, String author, int pages) {
        this.title = title;
        this.author = author;
        this.pages = pages;
    }
 // Getter methods for private fields
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPages() {
        return pages;
    }
    
    // Method to display book details (Polymorphism - Method Overriding)
    public void displayDetails() {
        System.out.println("Title: " + getTitle());
        System.out.println("Author: " + getAuthor());
        System.out.println("Pages: " + getPages());
    }
}
// Inheritance and Polymorphism - Class for a FictionBook, inheriting from Book
class FictionBook extends StoryBook {
    private String genre;

    // Constructor to initialize FictionBook object
    public FictionBook(String title, String author, int pages, String genre) {
        super(title, author, pages);
        this.genre = genre;
    }
    // Method to display fiction book details (Polymorphism - Method Overriding)
    @Override
    public void displayDetails() {
        super.displayDetails(); // Calls parent class method
        System.out.println("Genre: " + genre);
    }
}

public class oopsConceptDemo {

	public static void main(String[] args) {
		
		 // Creating objects of Book and FictionBook classes
        StoryBook book1 = new StoryBook("The Alchemist", "Paulo Coelho", 208);
        FictionBook fictionBook1 = new FictionBook("Harry Potter", "J.K. Rowling", 320, "Fantasy");

        // Calling methods on Book and FictionBook objects
        System.out.println("--- Book Details ---");
        book1.displayDetails();

        System.out.println("\n--- Fiction Book Details ---");
        fictionBook1.displayDetails();
		
		
	}
}
