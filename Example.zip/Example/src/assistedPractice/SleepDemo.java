package assistedPractice;

public class SleepDemo {

	public static void main(String[] args) {
		 System.out.println("Starting the program...");
	        
	        try {
	            System.out.println("Waiting for 2 seconds...");
	            Thread.sleep(2000); // Sleep for 2 seconds
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        
	        System.out.println("Resuming the program after sleep.");
	}

}
