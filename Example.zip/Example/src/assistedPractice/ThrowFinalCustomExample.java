package assistedPractice;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}


public class ThrowFinalCustomExample {
	  // Method that throws an exception using 'throws'
    public static void methodWithThrows(int value) throws CustomException {
        if (value < 0) {
            throw new CustomException("Value cannot be negative!");
        }
        System.out.println("Value is valid: " + value);
    }
	public static void main(String[] args) {
		 try {
	            // Calling a method that throws an exception using 'throws'
	            methodWithThrows(-5);
	        } catch (CustomException e) {
	            // Catching the custom exception
	            System.out.println("Caught CustomException: " + e.getMessage());
	        } finally {
	            // 'finally' block executes regardless of whether an exception is caught
	            System.out.println("Finally block executed.");
	        }

	        // Throwing an exception manually using 'throw'
	        try {
	            int divisor = 0;
	            if (divisor == 0) {
	                throw new ArithmeticException("Cannot divide by zero!");
	            }
	            int result = 10 / divisor;
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Caught ArithmeticException: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }

	}

}
