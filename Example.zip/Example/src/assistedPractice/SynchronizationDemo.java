package assistedPractice;

//Class with a shared resource and methods to manipulate it
class SharedResource {
 private int count = 0;

 // Synchronized method to increment the count
 public synchronized void increment() {
     count++;
     System.out.println("Incremented count to: " + count);
 }
}

//Runnable task that uses the shared resource
class ExRunnable implements Runnable {
 private SharedResource sharedResource;

 public ExRunnable(SharedResource sharedResource) {
     this.sharedResource = sharedResource;
 }

 public void run() {
     for (int i = 0; i < 5; i++) {
         sharedResource.increment();
         try {
             Thread.sleep(100); // Simulating some work
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
     }
 }
}
public class SynchronizationDemo {

	public static void main(String[] args) {
		// Creating a shared resource object
        SharedResource sharedResource = new SharedResource();

        // Creating multiple threads that use the same shared resource
        Thread thread1 = new Thread(new ExRunnable(sharedResource));
        Thread thread2 = new Thread(new ExRunnable(sharedResource));

        // Starting the threads
        thread1.start();
        thread2.start();

	}

}
