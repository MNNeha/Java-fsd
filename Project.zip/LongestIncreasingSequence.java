package pgm2Ex;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class LongestIncreasingSequence {
	public static List<Integer> longestIncreasingSubsequence(int[] nums) {
    if (nums == null || nums.length == 0) {
        return new ArrayList<>();
    }

    int n = nums.length;
    int[] lis = new int[n];
    Arrays.fill(lis, 1);

    for (int i = 1; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (nums[i] > nums[j] && lis[i] < lis[j] + 1) {
                lis[i] = lis[j] + 1;
            }
        }
    }

    int maxLength = Arrays.stream(lis).max().orElse(0);
    int maxIndex = -1;
    for (int i = 0; i < n; i++) {
        if (lis[i] == maxLength) {
            maxIndex = i;
            break;
        }
    }

    List<Integer> subsequence = new ArrayList<>();
    subsequence.add(nums[maxIndex]);
    maxLength--;

    for (int i = maxIndex - 1; i >= 0; i--) {
        if (nums[i] < nums[maxIndex] && lis[i] == maxLength) {
            subsequence.add(nums[i]);
            maxIndex = i;
            maxLength--;
        }
    }

    return reverseList(subsequence);
}

public static List<Integer> reverseList(List<Integer> list) {
    List<Integer> reversedList = new ArrayList<>(list);
    int left = 0;
    int right = reversedList.size() - 1;
    while (left < right) {
        int temp = reversedList.get(left);
        reversedList.set(left, reversedList.get(right));
        reversedList.set(right, temp);
        left++;
        right--;
    }
    return reversedList;
}
	public static void main(String[] args) {
		 Random random = new Random();
	        int n = random.nextInt(99) + 1;
	        int[] randomNumbers = new int[n];
	        for (int i = 0; i < n; i++) {
	            randomNumbers[i] = random.nextInt(100);
	        }

	        System.out.println("Generated list of numbers: " + Arrays.toString(randomNumbers));
	        List<Integer> result = longestIncreasingSubsequence(randomNumbers);
	        System.out.println("Longest increasing subsequence: " + result);

	}

}
