package AlgoDemo;

import java.util.Arrays;

public class MergeSortDemo {
	public static void mergeSort(int[] arr) {
		if(arr.length >1) {
			int mid=arr.length/2;
			
			//split the array into two halves
			int[] left = Arrays.copyOfRange(arr, 0, mid);
			int[] right = Arrays.copyOfRange(arr, mid, arr.length);
			
			//Recursively sort the two halves
			mergeSort(left);
			mergeSort(right);
			
			//merge the sorted halves
			merge(arr,left,right);			
		}
	}
	public static void merge(int[] arr,int[] left,int[] right) {
		int i =0,j=0,k=0;
		
		//merge the two arrays:left and right
		while(i<left.length && j<right.length) {
			if(left[i]<=right[j]) {
				arr[k++]=left[i++];
				
			}else {
				arr[k++] = right[j++];
			}
		}
		//copy remaining elements of the right[] i any
		while(j < left.length) {
			arr[k++]=right[j++];
		}
		//copy remaining elements of right[]if any
		while (j<right.length) {
			arr[k++]=right[j++];
		}
		
	}
	
public static void main (String[] args) {
	int [] array= {100,10,45,60,2,75};
	
	
	System.out.println("Original Array: "+Arrays.toString(array));
	
	mergeSort(array);
	
	System.out.println("Sorted Array: "+Arrays.toString(array));
}
}
