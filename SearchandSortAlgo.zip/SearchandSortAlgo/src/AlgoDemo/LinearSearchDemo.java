package AlgoDemo;

public class LinearSearchDemo {

	public static void main(String[] args) {
		int arr[] = {10,22,35,46,57,60,75};
		
		int key = 57;
		
		int positionOfKey = doLinearSearch(arr, key);
		if(positionOfKey != -1)
			System.out.println("Found the key " + key +" at Location "+positionOfKey);
		else
			System.out.println("key "+key+"not found ");
		key = 30;
		
		positionOfKey = doLinearSearch(arr, key);
		
		if(positionOfKey != -1)
			System.out.println("found the key" +key+"at Location "+positionOfKey);
		else
			System.out.println("key " + key+" not found ");
	}

	private static int doLinearSearch(int[] arr, int key) {
		int positionOfKey = -1;
		
		for(int i = 0;i<arr.length;i++){
			if(arr[i] == key) {
				positionOfKey = i;
				break;
			}
		}
		return positionOfKey;
	}

}
