package AlgoDemo;

import java.util.Arrays;

public class insertionSortDemo {
public static void InsertionSort(int[] arr) {
	int n=arr.length;
	//traverse through the array,starting from the second element
	for (int i = 1;i<n;i++) {
		int key = arr[i];
		int j =i-1;
		
		
		//move elements of arr[0..i-1],that are greater than key,
		//to one position ahead of their crrent psoition
		while(j>= 0 && arr[j]>key) {
			arr[j+1]=arr[j];
			j=j-1;
			
		}
		arr[j+1]= key;
	}
}
	
	public static void main(String[] args) {
	int[] array= {95,12,44,23,55,1,30};
	
	System.out.println("Original Array: "+Arrays.toString(array));
	
	InsertionSort(array);
	
	System.out.println("Sorted Array: "+Arrays.toString(array));

	}

}
