package AlgoDemo;
import java.util.Arrays;
public class ExponentialSearchAlgoDemo {

	public static int exponentialSearch(int[] arr,int target) {
		int n = arr.length;
		if(arr[0] == target) {
			return 0;//if the element is at the first position
		}
		int i =1;
		while (i < n && arr[i]<=target) {
			i *=2;//dobuling for each iteration
		}
		return binarySearch(arr,i/2,Math.min(i, n),target);
	}
	public static int binarySearch(int[] arr, int left, int right, int target) {
	    if (right >= left) {
	        int mid = left + (right - left) / 2;
	        if (arr[mid] == target) {
	            return mid;
	        }
	        if (arr[mid] > target) {
	            return binarySearch(arr, left, mid - 1, target);
	        }
	        return binarySearch(arr, mid + 1, right, target);
	    }
	    return -1; // Element not found
	}


	public static void main(String[] args) {
		int[] array= {2,4,6,8,10,12,14,16,18,20};
		int targetElement = 12;
		
		int index = exponentialSearch(array, targetElement);
		
		if(index != -1) {
			System.out.println("Element found at index: "+index);
			
		}else {
			System.out.println("Elements not found in the array.");
		}

	}

}
