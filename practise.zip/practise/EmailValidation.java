package practise;

    import java.util.Scanner;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;

	public class EmailValidation {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Sample email IDs for validation
	        String[] sampleEmails = {
	                "example@example.com",
	                "test@test.co.uk",
	                "user123@gmail.com",
	                "example324@yahoo.com",
	                "user_190@reddit.org"
	        };

	        // Regular expression pattern for email validation
	        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	        Pattern pattern = Pattern.compile(emailPattern);

	        System.out.println("Enter an email address for validation:");
	        String userEmail = scanner.nextLine();

	        // Validate user input against the pattern
	        Matcher matcher = pattern.matcher(userEmail);
	        boolean isValid = matcher.matches();

	        if (isValid) {
	            System.out.println("The email address entered is valid.");
	        } else {
	            System.out.println("The email address entered is not valid.");
	        }

	        System.out.println("\nSample email IDs for validation:");
	        for (String sampleEmail : sampleEmails) {
	            matcher = pattern.matcher(sampleEmail);
	            isValid = matcher.matches();
	            System.out.println(sampleEmail + " - Valid: " + isValid);
	        }

	        scanner.close();
	    }
	}

