

import java.io.*;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DemoJDBC extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // JDBC connection initialization
        Connection conn = null;
        try {
            // Load the driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Assuming you have a config.properties file with JDBC credentials
            // Read the credentials from the file
            String url = "jdbc:mysql://localhost:3306/your_database";
            String username = "your_username";
            String password = "your_password";
            
            // Establish the connection
            conn = DriverManager.getConnection(url, username, password);
            
            out.println("JDBC connection established successfully!");
            
            // Perform any database operations here
            
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (conn != null)
                    conn.close(); // Closing the connection
            } catch (SQLException ex) {
                out.println("Error: " + ex.getMessage());
            }
        }
    }
}
