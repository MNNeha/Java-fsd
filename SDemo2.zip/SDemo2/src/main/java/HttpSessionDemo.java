
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/HttpSessionDemo")
public class HttpSessionDemo extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        
        // Get the session
        HttpSession session = request.getSession(true);

        // Set session attributes
        session.setAttribute("username", "JohnDoe");
        session.setAttribute("email", "john@example.com");

        // Retrieve session attributes
        String username = (String) session.getAttribute("username");
        String email = (String) session.getAttribute("email");

        // Display session information
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Session Tracking using HttpSession</h2>");
        response.getWriter().println("<p>Username: " + username + "</p>");
        response.getWriter().println("<p>Email: " + email + "</p>");
        response.getWriter().println("</body></html>");
    }
}

