import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/HiddenFieldDemo")
public class HiddenFieldDemo extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession(true);

        // Retrieve the session ID
        String sessionID = session.getId();

        // HTML form with a hidden field containing the session ID
        String form = "<form action='HiddenFieldDemo' method='post'>" +
                "   <input type='hidden' name='sessionID' value='" + sessionID + "'>" +
                "   <input type='submit' value='Submit'>" +
                "</form>";

        // Print the form with the hidden session ID field
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Session Tracking using Hidden Form Fields</h2>");
        response.getWriter().println("<p>Session ID: " + sessionID + "</p>");
        response.getWriter().println(form);
        response.getWriter().println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the session ID from the hidden field
        String sessionID = request.getParameter("sessionID");

        response.setContentType("text/html");

        // Display the session ID received from the hidden field
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Session ID received from Hidden Field:</h2>");
        response.getWriter().println("<p>" + sessionID + "</p>");
        response.getWriter().println("</body></html>");
    }
}

