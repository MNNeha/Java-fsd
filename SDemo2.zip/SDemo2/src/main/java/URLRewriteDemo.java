
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/URLRewriteDemo")
public class URLRewriteDemo extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession(true);

        // Retrieve the session ID
        String sessionID = session.getId();

        // Create a new URL with the session ID appended as a parameter
        String urlWithSession = response.encodeURL("URLRewriteDemo");

        // Print the URL with the session ID
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Session Tracking using URL Rewriting</h2>");
        response.getWriter().println("<p>Session ID: " + sessionID + "</p>");
        response.getWriter().println("<p>URL with Session ID: <a href='" + urlWithSession + "'>" + urlWithSession + "</a></p>");
        response.getWriter().println("</body></html>");
    }
}
