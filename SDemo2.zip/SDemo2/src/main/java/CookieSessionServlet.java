import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CookieSessionServlet")
public class CookieSessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the existing cookie for session tracking
        Cookie[] cookies = request.getCookies();
        String sessionID = null;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("sessionId")) {
                    sessionID = cookie.getValue();
                    break;
                }
            }
        }

        // If no session cookie is found, create a new one
        if (sessionID == null) {
            sessionID = "ABC123"; // Replace this with a session ID generator
            Cookie sessionCookie = new Cookie("sessionId", sessionID);
            response.addCookie(sessionCookie);
            out.println("Session Cookie Created. Session ID: " + sessionID);
        } else {
            out.println("Session ID from Cookie: " + sessionID);
        }
    }
}
