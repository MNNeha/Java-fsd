package pgm3Ex;
class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;
    Node tail;

    DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    void traverseForward() {
        System.out.println("Forward traversal:");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    void traverseBackward() {
        System.out.println("Backward traversal:");
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
public class TraverseDoubleLL {

	public static void main(String[] args) {
		   DoublyLinkedList list = new DoublyLinkedList();
	        list.insert(3);
	        list.insert(5);
	        list.insert(7);
	        list.insert(9);

	        list.traverseForward();
	        list.traverseBackward();
	}

}
