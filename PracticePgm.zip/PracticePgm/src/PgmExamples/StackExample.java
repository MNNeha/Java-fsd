package PgmExamples;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		 Stack<Integer> stack = new Stack<>();

	        // Inserting elements (pushing) into the stack
	        stack.push(5);
	        stack.push(10);
	        stack.push(15);

	        System.out.println("Stack elements after pushing:");
	        System.out.println(stack);

	        // Removing elements (popping) from the stack
	        int poppedElement = stack.pop(); // Removes and returns the top element
	        System.out.println("\nPopped element: " + poppedElement);
	        System.out.println("Stack elements after popping:");
	        System.out.println(stack);

	        // Inserting (pushing) more elements
	        stack.push(20);
	        stack.push(25);

	        System.out.println("\nStack elements after pushing more elements:");
	        System.out.println(stack);

	}

}
