package PgmExamples;
public class SumInRange {
    public static int sumInRange(int[] arr, int L, int R) {
        if (arr == null || L < 0 || R >= arr.length || L > R) {
            throw new IllegalArgumentException("Invalid input");
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] elements = {3, 7, 2, 9, 4, 1, 8};
        int n = elements.length;
        int L = 2; // Example lower range
        int R = 5; // Example upper range

        int result = sumInRange(elements, L, R);
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + result);
    }
}
