package PgmExamples;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    SinglyLinkedList() {
        this.head = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    void deleteNode(int key) {
        Node temp = head;
        Node prev = null;

        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Key not found in the list");
            return;
        }

        prev.next = temp.next;
    }

    void displayList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteFirstOccurrence {

	public static void main(String[] args) {
		
		SinglyLinkedList list = new SinglyLinkedList();
        list.insert(5);
        list.insert(2);
        list.insert(7);
        list.insert(2);
        list.insert(8);

        System.out.println("Original list:");
        list.displayList();

        int keyToDelete = 2;
        list.deleteNode(keyToDelete);

        System.out.println("List after deleting first occurrence of " + keyToDelete + ":");
        list.displayList();

	}

}
