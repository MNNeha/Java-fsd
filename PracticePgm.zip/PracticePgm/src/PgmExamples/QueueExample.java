package PgmExamples;

import java.util.LinkedList;
import java.util.Queue;


public class QueueExample {
public static void main (String[] args) {
	 Queue<Integer> queue = new LinkedList<>();

     // Inserting elements (enqueue) into the queue
     queue.offer(5);
     queue.offer(10);
     queue.offer(15);

     System.out.println("Queue elements after enqueuing:");
     System.out.println(queue);

     // Removing elements (dequeue) from the queue
     int dequeuedElement = queue.poll(); // Removes and returns the front element
     System.out.println("\nDequeued element: " + dequeuedElement);
     System.out.println("Queue elements after dequeuing:");
     System.out.println(queue);

     // Inserting (enqueue) more elements
     queue.offer(20);
     queue.offer(25);

     System.out.println("\nQueue elements after enqueuing more elements:");
     System.out.println(queue);	
}
	
	
	
}
