package pgm2Ex;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        this.head = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (head.data >= newNode.data) {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newNode.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void displayList() {
        if (head == null) {
            System.out.println("Circular Linked List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}


public class SortedCircularLL {

	public static void main(String[] args) {
		   CircularLinkedList list = new CircularLinkedList();
	        list.insert(3);
	        list.insert(5);
	        list.insert(7);
	        list.insert(9);

	        System.out.println("Original list:");
	        list.displayList();

	        int elementToInsert = 6;
	        list.insert(elementToInsert);

	        System.out.println("List after inserting " + elementToInsert + ":");
	        list.displayList();
	}

}
